import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import matplotlib.gridspec as gridspec
from matplotlib.patches import FancyBboxPatch
import warnings
import os

warnings.filterwarnings("ignore")

DATA_PATH  = "data/Walmart.csv"
OUTPUT_DIR = "images"
os.makedirs(OUTPUT_DIR, exist_ok=True)

C = {
    "blue"      : "#0071CE",
    "yellow"    : "#FFC220",
    "dark"      : "#1A1A2E",
    "bg"        : "#F5F2EB",
    "white"     : "#FFFFFF",
    "green"     : "#1A7A4A",
    "red"       : "#C0392B",
    "orange"    : "#E67E22",
    "muted"     : "#7A7060",
    "border"    : "#E8E2D6",
    "blue_light": "#E8F4FF",
}

plt.rcParams.update({
    "figure.facecolor"  : C["bg"],
    "axes.facecolor"    : C["white"],
    "axes.edgecolor"    : C["border"],
    "axes.labelcolor"   : C["muted"],
    "axes.spines.top"   : False,
    "axes.spines.right" : False,
    "axes.grid"         : True,
    "grid.color"        : C["border"],
    "grid.linewidth"    : 0.6,
    "grid.alpha"        : 0.7,
    "xtick.color"       : C["muted"],
    "ytick.color"       : C["muted"],
    "xtick.labelsize"   : 8,
    "ytick.labelsize"   : 8,
    "font.family"       : "DejaVu Sans",
    "legend.frameon"    : True,
    "legend.framealpha" : 0.9,
    "legend.edgecolor"  : C["border"],
    "legend.fontsize"   : 8,
})

FT = {"fontsize": 13, "fontweight": "bold", "color": C["dark"]}
FL = {"fontsize":  8, "color": C["muted"]}


def load_data(path):
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip()
    df["Date"]       = pd.to_datetime(df["Date"], dayfirst=True)
    df["Year"]       = df["Date"].dt.year
    df["Month"]      = df["Date"].dt.month
    df["Quarter"]    = df["Date"].dt.quarter
    df["Week"]       = df["Date"].dt.isocalendar().week.astype(int)
    df["YearMonth"]  = df["Date"].dt.to_period("M")
    df["YearQ"]      = df["Year"].astype(str) + "-Q" + df["Quarter"].astype(str)
    df["MonthName"]  = df["Date"].dt.strftime("%b")
    df["Is_Holiday"] = df["Holiday_Flag"].astype(bool)
    df["Unemp_Band"] = pd.cut(df["Unemployment"], bins=[0,6,8,10,100],
                               labels=["<6%","6–8%","8–10%",">10%"])
    df["Fuel_Band"]  = pd.cut(df["Fuel_Price"], bins=[0,3.0,3.5,4.0,99],
                               labels=["<$3.0","$3.0–3.5","$3.5–4.0",">$4.0"])
    df["Temp_Band"]  = pd.cut(df["Temperature"], bins=[-50,32,60,80,200],
                               labels=["Freezing","Cool","Warm","Hot"])
    return df


def kpi_box(ax, title, value, subtitle, color, icon=""):
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis("off")
    rect = FancyBboxPatch((0.03,0.08), 0.94, 0.84,
                          boxstyle="round,pad=0.02", linewidth=1.5,
                          edgecolor=color, facecolor=C["white"], zorder=2)
    ax.add_patch(rect)
    ax.axhline(y=0.92, xmin=0.03, xmax=0.97, color=color, linewidth=4, zorder=3)
    ax.text(0.1,  0.72, icon,     fontsize=18, va="center", zorder=4)
    ax.text(0.5,  0.54, value,    ha="center", va="center", fontsize=17,
            fontweight="bold", color=C["dark"], zorder=4)
    ax.text(0.5,  0.33, title,    ha="center", va="center", fontsize=8,
            color=C["muted"], zorder=4)
    ax.text(0.5,  0.17, subtitle, ha="center", va="center", fontsize=7,
            color=color, zorder=4)


def plot_overview(df):
    fig = plt.figure(figsize=(20,14), facecolor=C["bg"])
    fig.suptitle("WALMART BUSINESS INSIGHTS DASHBOARD", fontsize=22,
                 fontweight="bold", color=C["dark"], y=0.98)
    fig.text(0.5, 0.955, "45 Stores · Weekly Sales · Feb 2010 – Oct 2012 · 6,435 Records",
             ha="center", fontsize=10, color=C["muted"])
    gs = gridspec.GridSpec(3, 4, figure=fig, hspace=0.45, wspace=0.35,
                           top=0.93, bottom=0.06, left=0.05, right=0.97)

    total    = df["Weekly_Sales"].sum()
    avg_wk   = df["Weekly_Sales"].mean()
    best_s   = df.groupby("Store")["Weekly_Sales"].sum()
    hol_rev  = df[df["Is_Holiday"]]["Weekly_Sales"].sum()

    kpis = [
        (fig.add_subplot(gs[0,0]), "TOTAL REVENUE",      f"${total/1e9:.2f}B",    "3-Year Network Total",        C["blue"],   "💰"),
        (fig.add_subplot(gs[0,1]), "AVG WEEKLY / STORE", f"${avg_wk/1e3:.0f}K",   "Per store per week",          C["yellow"], "📦"),
        (fig.add_subplot(gs[0,2]), f"BEST STORE (#{best_s.idxmax()})", f"${best_s.max()/1e6:.0f}M", "#1 of 45 Stores", C["green"], "🏆"),
        (fig.add_subplot(gs[0,3]), "HOLIDAY REVENUE",    f"${hol_rev/1e6:.0f}M",  f"{hol_rev/total*100:.1f}% of Total", C["orange"], "🎉"),
    ]
    for ax, *args in kpis:
        kpi_box(ax, *args)

    ax_t = fig.add_subplot(gs[1,:])
    monthly = df.groupby("YearMonth")["Weekly_Sales"].sum().reset_index()
    monthly["YM"]      = monthly["YearMonth"].astype(str)
    monthly["Sales_M"] = monthly["Weekly_Sales"] / 1e6
    m10 = monthly[monthly["YM"].str.startswith("2010")]
    m11 = monthly[monthly["YM"].str.startswith("2011")]
    m12 = monthly[monthly["YM"].str.startswith("2012")]
    x_all = range(len(monthly))
    ax_t.fill_between(x_all, monthly["Sales_M"], alpha=0.08, color=C["blue"])
    ax_t.plot(range(len(m10)), m10["Sales_M"].values,
              color=C["blue"],   lw=2.5, label="2010", marker="o", ms=4)
    ax_t.plot(range(len(m10), len(m10)+len(m11)), m11["Sales_M"].values,
              color=C["green"],  lw=2.5, label="2011", marker="s", ms=4)
    ax_t.plot(range(len(m10)+len(m11), len(monthly)), m12["Sales_M"].values,
              color=C["orange"], lw=2.5, label="2012 (partial)", marker="^", ms=4)
    pk = monthly["Sales_M"].idxmax()
    ax_t.annotate(f"Peak: ${monthly.loc[pk,'Sales_M']:.0f}M",
                  xy=(pk, monthly.loc[pk,"Sales_M"]),
                  xytext=(pk-2, monthly.loc[pk,"Sales_M"]+12),
                  arrowprops=dict(arrowstyle="->", color=C["blue"], lw=1.5),
                  fontsize=8, color=C["blue"], fontweight="bold")
    ax_t.set_xticks(range(len(monthly)))
    ax_t.set_xticklabels(monthly["YM"].values, rotation=45, ha="right", fontsize=7)
    ax_t.set_ylabel("Sales ($M)", **FL)
    ax_t.set_title("Monthly Revenue Trend — All 45 Stores Combined", **FT)
    ax_t.legend(loc="upper left")
    ax_t.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}M"))

    ax_ann = fig.add_subplot(gs[2,0])
    yearly = df.groupby("Year")["Weekly_Sales"].sum() / 1e6
    bars   = ax_ann.bar(yearly.index.astype(str), yearly.values,
                        color=[C["blue"],C["green"],C["orange"]],
                        edgecolor="white", linewidth=1.5, width=0.5)
    for bar, val in zip(bars, yearly.values):
        ax_ann.text(bar.get_x()+bar.get_width()/2, bar.get_height()+15,
                    f"${val:.0f}M", ha="center", fontsize=8,
                    fontweight="bold", color=C["dark"])
    ax_ann.set_title("Annual Revenue", **FT)
    ax_ann.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}M"))

    ax_q = fig.add_subplot(gs[2,1])
    qdata = df.groupby(["Year","Quarter"])["Weekly_Sales"].sum().reset_index()
    qdata["Label"] = "Q"+qdata["Quarter"].astype(str)+" '"+qdata["Year"].astype(str).str[-2:]
    qcolors = [C["blue"] if q==4 else (C["yellow"] if q==3 else "#90CAF9") for q in qdata["Quarter"]]
    ax_q.bar(range(len(qdata)), qdata["Weekly_Sales"]/1e6,
             color=qcolors, edgecolor="white", linewidth=1, width=0.7)
    ax_q.set_xticks(range(len(qdata)))
    ax_q.set_xticklabels(qdata["Label"].values, rotation=45, ha="right", fontsize=7)
    ax_q.set_title("Quarterly Sales", **FT)
    ax_q.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}M"))
    ax_q.legend(handles=[
        mpatches.Patch(color=C["blue"],   label="Q4 (Holiday)"),
        mpatches.Patch(color=C["yellow"], label="Q3"),
        mpatches.Patch(color="#90CAF9",   label="Q1/Q2"),
    ], fontsize=7)

    ax_pie = fig.add_subplot(gs[2,2])
    hol_s  = df[df["Is_Holiday"]]["Weekly_Sales"].sum()
    nhol_s = df[~df["Is_Holiday"]]["Weekly_Sales"].sum()
    ax_pie.pie([hol_s, nhol_s],
               labels=["Holiday\nWeeks","Regular\nWeeks"],
               autopct="%1.1f%%", startangle=90,
               colors=[C["yellow"],C["blue"]],
               wedgeprops=dict(edgecolor="white",linewidth=2),
               textprops={"fontsize":8})
    ax_pie.set_title("Holiday vs Regular", **FT)

    ax_yoy = fig.add_subplot(gs[2,3])
    yoy    = df.groupby("Year")["Weekly_Sales"].sum()
    growth = yoy.pct_change() * 100
    colors_g = [C["green"] if v>0 else C["red"] for v in growth.values[1:]]
    ax_yoy.bar(yoy.index[1:].astype(str), growth.values[1:],
               color=colors_g, edgecolor="white", linewidth=1, width=0.4)
    for i, (yr, g) in enumerate(zip(yoy.index[1:], growth.values[1:])):
        ax_yoy.text(i, g+0.3, f"{g:+.1f}%", ha="center", fontsize=9,
                    fontweight="bold", color=C["green"] if g>0 else C["red"])
    ax_yoy.axhline(0, color=C["border"], linewidth=1)
    ax_yoy.set_title("YoY Revenue Growth", **FT)
    ax_yoy.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"{x:.0f}%"))

    plt.savefig(f"{OUTPUT_DIR}/01_overview_dashboard.png", dpi=150,
                bbox_inches="tight", facecolor=C["bg"])
    plt.close()


def plot_store_performance(df):
    fig = plt.figure(figsize=(20,16), facecolor=C["bg"])
    fig.suptitle("STORE PERFORMANCE ANALYSIS", fontsize=20,
                 fontweight="bold", color=C["dark"], y=0.98)
    fig.text(0.5, 0.955, "Revenue Rankings · Variability · Consistency · Scorecards",
             ha="center", fontsize=10, color=C["muted"])
    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.35,
                           top=0.93, bottom=0.06, left=0.05, right=0.97)

    sa = df.groupby("Store").agg(
        Total_Sales=("Weekly_Sales","sum"),
        Avg_Weekly =("Weekly_Sales","mean"),
        Std_Weekly =("Weekly_Sales","std"),
        Max_Weekly =("Weekly_Sales","max"),
    ).reset_index()
    sa["CV"]      = sa["Std_Weekly"] / sa["Avg_Weekly"] * 100
    sa["Total_M"] = sa["Total_Sales"] / 1e6
    sa["Avg_K"]   = sa["Avg_Weekly"]  / 1e3
    sa = sa.sort_values("Total_Sales", ascending=False).reset_index(drop=True)
    sa["Rank"] = range(1, len(sa)+1)

    ax1 = fig.add_subplot(gs[:2,:2])
    colors_r = [C["blue"] if i<5 else (C["yellow"] if i<15 else
                (C["orange"] if i<30 else C["red"])) for i in range(len(sa))]
    bars = ax1.barh([f"Store {s}" for s in sa["Store"]], sa["Total_M"],
                    color=colors_r, edgecolor="white", linewidth=0.8, height=0.7)
    ax1.set_xlabel("Total Revenue ($M)", **FL)
    ax1.set_title("All 45 Stores — 3-Year Cumulative Revenue", **FT)
    ax1.xaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}M"))
    ax1.invert_yaxis()
    ax1.tick_params(axis="y", labelsize=7)
    net_avg = sa["Total_M"].mean()
    ax1.axvline(net_avg, color=C["muted"], lw=1.5, ls="--")
    ax1.text(net_avg+1, len(sa)-1, f"Avg ${net_avg:.0f}M", color=C["muted"], fontsize=8)
    for i, (bar, row) in enumerate(zip(bars, sa.itertuples())):
        if i < 10:
            ax1.text(row.Total_M+1, bar.get_y()+bar.get_height()/2,
                     f"${row.Total_M:.0f}M", va="center", fontsize=7, color=C["dark"])
    ax1.legend(handles=[
        mpatches.Patch(color=C["blue"],   label="Top 5"),
        mpatches.Patch(color=C["yellow"], label="Rank 6–15"),
        mpatches.Patch(color=C["orange"], label="Rank 16–30"),
        mpatches.Patch(color=C["red"],    label="Bottom 15"),
    ], loc="lower right", fontsize=8)

    ax2 = fig.add_subplot(gs[0,2])
    sc = ax2.scatter(sa["Avg_K"], sa["Std_Weekly"]/1e3,
                     c=sa["Total_M"], cmap="Blues", s=60,
                     edgecolors=C["dark"], linewidth=0.5, alpha=0.85)
    plt.colorbar(sc, ax=ax2, label="Total Rev ($M)", fraction=0.04, pad=0.02)
    for _, row in sa.head(5).iterrows():
        ax2.annotate(f"#{row['Store']}", (row["Avg_K"], row["Std_Weekly"]/1e3),
                     textcoords="offset points", xytext=(4,4), fontsize=7, color=C["blue"])
    ax2.set_xlabel("Avg Weekly Sales ($K)", **FL)
    ax2.set_ylabel("Std Dev ($K)", **FL)
    ax2.set_title("Avg Revenue vs Variability", **FT)

    ax3 = fig.add_subplot(gs[1,2])
    top10_ids = sa.head(10)["Store"].tolist()
    box_data  = [df[df["Store"]==s]["Weekly_Sales"].values/1e3 for s in top10_ids]
    bp = ax3.boxplot(box_data, patch_artist=True, notch=False,
                     medianprops=dict(color=C["yellow"], linewidth=2))
    for patch, color in zip(bp["boxes"], [C["blue"]]*5+["#90CAF9"]*5):
        patch.set_facecolor(color); patch.set_alpha(0.7)
    ax3.set_xticklabels([f"#{s}" for s in top10_ids], rotation=45, fontsize=7)
    ax3.set_ylabel("Weekly Sales ($K)", **FL)
    ax3.set_title("Top 10 — Sales Distribution", **FT)

    ax4 = fig.add_subplot(gs[2,:])
    ax4.axis("off")
    top10 = sa.head(10).copy()
    top10["Share%"] = (top10["Total_M"]/sa["Total_M"].sum()*100).round(1)
    top10["vs_avg"] = ((top10["Total_M"]/net_avg-1)*100).round(1)
    top10["Max_K"]  = (top10["Max_Weekly"]/1e3).round(1)
    top10["CV_str"] = top10["CV"].round(1).astype(str)+"%"
    col_labels = ["Rank","Store","Total Rev ($M)","Avg Weekly ($K)",
                  "Peak Week ($K)","Variability (CV)","Network Share %","vs Avg Store %"]
    cell_text = []
    for _, row in top10.iterrows():
        cell_text.append([
            f"#{int(row['Rank'])}", f"Store {int(row['Store'])}",
            f"${row['Total_M']:.1f}M", f"${row['Avg_K']:.1f}K",
            f"${row['Max_K']:.1f}K",  row["CV_str"],
            f"{row['Share%']}%",      f"+{row['vs_avg']:.1f}%",
        ])
    tbl = ax4.table(cellText=cell_text, colLabels=col_labels,
                    cellLoc="center", loc="center", bbox=[0,0.1,1,0.88])
    tbl.auto_set_font_size(False); tbl.set_fontsize(8.5)
    for (r,c), cell in tbl.get_celld().items():
        cell.set_edgecolor(C["border"])
        if r==0:
            cell.set_facecolor(C["dark"]); cell.set_text_props(color="white",fontweight="bold")
        elif r%2==0:
            cell.set_facecolor("#F0EEE8")
        else:
            cell.set_facecolor(C["white"])
    ax4.set_title("Top 10 Stores — Detailed Performance Scorecard", **FT, pad=14)

    plt.savefig(f"{OUTPUT_DIR}/02_store_performance.png", dpi=150,
                bbox_inches="tight", facecolor=C["bg"])
    plt.close()


def plot_economic_factors(df):
    fig = plt.figure(figsize=(20,15), facecolor=C["bg"])
    fig.suptitle("ECONOMIC FACTORS & SALES CORRELATION", fontsize=20,
                 fontweight="bold", color=C["dark"], y=0.98)
    fig.text(0.5, 0.955,
             "Unemployment · Fuel Price · CPI · Temperature — Impact on Weekly Store Sales",
             ha="center", fontsize=10, color=C["muted"])
    gs = gridspec.GridSpec(3, 3, figure=fig, hspace=0.45, wspace=0.38,
                           top=0.93, bottom=0.06, left=0.06, right=0.97)

    sales_k = df["Weekly_Sales"] / 1e3

    for col, idx, color, bg_color, label in [
        ("Unemployment",  (0,0), C["red"],    "#FFEBEE", "Unemployment Rate (%)"),
        ("Fuel_Price",    (0,1), C["orange"], "#FFF3E0", "Fuel Price ($/gal)"),
        ("Temperature",   (0,2), C["green"],  "#E8F5E9", "Temperature (°F)"),
    ]:
        ax = fig.add_subplot(gs[idx[0], idx[1]])
        ax.scatter(df[col], sales_k, alpha=0.25, s=8, color=color, edgecolors="none")
        m, b = np.polyfit(df[col], sales_k, 1)
        x_l  = np.linspace(df[col].min(), df[col].max(), 100)
        ax.plot(x_l, m*x_l+b, color=C["red"], lw=2, ls="--")
        corr = df[col].corr(df["Weekly_Sales"])
        ax.text(0.05, 0.92, f"r = {corr:.3f}", transform=ax.transAxes,
                fontsize=8, color=color,
                bbox=dict(boxstyle="round,pad=0.3", facecolor=bg_color))
        ax.set_xlabel(label, **FL)
        ax.set_ylabel("Weekly Sales ($K)", **FL)
        ax.set_title(f"{col} vs Sales", **FT)

    for band_col, idx, colors, label in [
        ("Unemp_Band", (1,0), [C["green"],"#42A5F5",C["orange"],C["red"]], "Unemployment Band"),
        ("Fuel_Band",  (1,1), [C["green"],C["yellow"],C["orange"],C["red"]], "Fuel Price Band"),
        ("Temp_Band",  (1,2), ["#90CAF9",C["blue"],C["yellow"],C["red"]], "Temperature Band"),
    ]:
        ax  = fig.add_subplot(gs[idx[0], idx[1]])
        bd  = df.groupby(band_col, observed=True)["Weekly_Sales"].mean()/1e3
        brs = ax.bar(bd.index.astype(str), bd.values, color=colors,
                     edgecolor="white", linewidth=1.5, width=0.55)
        for bar, val in zip(brs, bd.values):
            ax.text(bar.get_x()+bar.get_width()/2, bar.get_height()+2,
                    f"${val:.0f}K", ha="center", fontsize=8,
                    fontweight="bold", color=C["dark"])
        ax.set_xlabel(label, **FL)
        ax.set_ylabel("Avg Weekly Sales ($K)", **FL)
        ax.set_title(f"Avg Sales by {band_col.replace('_',' ')}", **FT)
        ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}K"))
        ax.tick_params(axis="x", rotation=15)

    ax7 = fig.add_subplot(gs[2,:])
    cols = ["Weekly_Sales","Temperature","Fuel_Price","CPI","Unemployment"]
    lbls = ["Weekly Sales","Temperature","Fuel Price","CPI","Unemployment"]
    cm   = df[cols].corr()
    im   = ax7.imshow(cm.values, cmap="RdYlBu_r", aspect="auto", vmin=-1, vmax=1)
    plt.colorbar(im, ax=ax7, fraction=0.03, pad=0.02, label="Pearson r")
    ax7.set_xticks(range(len(lbls))); ax7.set_yticks(range(len(lbls)))
    ax7.set_xticklabels(lbls, fontsize=9)
    ax7.set_yticklabels(lbls, fontsize=9)
    for i in range(len(lbls)):
        for j in range(len(lbls)):
            val = cm.values[i,j]
            ax7.text(j, i, f"{val:.3f}", ha="center", va="center",
                     fontsize=10, fontweight="bold",
                     color="white" if abs(val)>0.5 else C["dark"])
    ax7.set_title("Full Correlation Matrix — Economic Factors vs Sales", **FT)

    plt.savefig(f"{OUTPUT_DIR}/03_economic_factors.png", dpi=150,
                bbox_inches="tight", facecolor=C["bg"])
    plt.close()


def plot_holiday_seasonal(df):
    fig = plt.figure(figsize=(20,14), facecolor=C["bg"])
    fig.suptitle("HOLIDAY & SEASONAL SALES PATTERNS", fontsize=20,
                 fontweight="bold", color=C["dark"], y=0.98)
    fig.text(0.5, 0.955,
             "Holiday Lift · Seasonal Rhythms · Monthly Averages · Week-of-Year Patterns",
             ha="center", fontsize=10, color=C["muted"])
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.35,
                           top=0.93, bottom=0.06, left=0.05, right=0.97)

    top20 = df.groupby("Store")["Weekly_Sales"].sum().nlargest(20).index.tolist()
    df20  = df[df["Store"].isin(top20)]
    h_st  = df20[df20["Is_Holiday"]].groupby("Store")["Weekly_Sales"].mean()/1e3
    nh_st = df20[~df20["Is_Holiday"]].groupby("Store")["Weekly_Sales"].mean()/1e3
    ss    = nh_st.sort_values(ascending=False).index
    x_s   = range(len(ss)); w = 0.35
    ax1 = fig.add_subplot(gs[0,:2])
    ax1.bar([i-w/2 for i in x_s], [nh_st.get(s,0) for s in ss], width=w,
            label="Regular Weeks", color=C["blue"], alpha=0.8, edgecolor="white")
    ax1.bar([i+w/2 for i in x_s], [h_st.get(s,0) for s in ss], width=w,
            label="Holiday Weeks", color=C["yellow"], alpha=0.9, edgecolor="white")
    ax1.set_xticks(list(x_s))
    ax1.set_xticklabels([f"#{s}" for s in ss], fontsize=8)
    ax1.set_ylabel("Avg Weekly Sales ($K)", **FL)
    ax1.set_title("Holiday vs Regular Week Sales — Top 20 Stores", **FT)
    ax1.legend()
    ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}K"))

    ax2 = fig.add_subplot(gs[0,2])
    h_avg  = df[df["Is_Holiday"]]["Weekly_Sales"].mean()
    nh_avg = df[~df["Is_Holiday"]]["Weekly_Sales"].mean()
    lift   = (h_avg/nh_avg-1)*100
    ax2.bar(["Regular\nWeeks","Holiday\nWeeks"],
            [nh_avg/1e3, h_avg/1e3],
            color=[C["blue"],C["yellow"]], edgecolor="white", linewidth=2, width=0.45)
    ax2.text(1, h_avg/1e3+10, f"+{lift:.1f}% lift\nvs regular",
             ha="center", fontsize=10, fontweight="bold", color=C["orange"])
    ax2.set_ylabel("Avg Weekly Sales ($K)", **FL)
    ax2.set_title("Holiday Sales Lift", **FT)
    ax2.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}K"))

    ax3 = fig.add_subplot(gs[1,0])
    m_avg   = df.groupby("Month")["Weekly_Sales"].mean()/1e3
    m_names = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
    b_cols  = [C["yellow"] if m in [11,12] else (C["blue"] if m in [7,8] else "#90CAF9")
               for m in range(1,13)]
    ax3.bar(m_names, m_avg.values, color=b_cols, edgecolor="white", linewidth=1.5, width=0.7)
    ax3.set_title("Seasonal Monthly Averages", **FT)
    ax3.set_ylabel("Avg Weekly Sales ($K)", **FL)
    ax3.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}K"))
    ax3.tick_params(axis="x", rotation=30)

    ax4 = fig.add_subplot(gs[1,1])
    w_avg   = df.groupby("Week")["Weekly_Sales"].mean()/1e3
    hol_wks = df[df["Is_Holiday"]]["Week"].unique()
    ax4.plot(w_avg.index, w_avg.values, color=C["blue"], lw=2, alpha=0.8)
    ax4.fill_between(w_avg.index, w_avg.values, alpha=0.08, color=C["blue"])
    for hw in hol_wks:
        if hw in w_avg.index:
            ax4.scatter(hw, w_avg[hw], color=C["yellow"], s=60, zorder=5)
    ax4.scatter([], [], color=C["yellow"], s=60, label="Holiday Weeks")
    ax4.set_xlabel("Week of Year", **FL)
    ax4.set_ylabel("Avg Sales ($K)", **FL)
    ax4.set_title("Sales by Week of Year", **FT)
    ax4.legend(fontsize=8)
    ax4.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}K"))

    ax5 = fig.add_subplot(gs[1,2])
    h_yr  = df[df["Is_Holiday"]].groupby("Year")["Weekly_Sales"].mean()
    nh_yr = df[~df["Is_Holiday"]].groupby("Year")["Weekly_Sales"].mean()
    x_yr  = np.arange(len(h_yr))
    ax5.bar(x_yr-0.2, nh_yr.values/1e3, 0.35, label="Regular Avg",
            color=C["blue"], alpha=0.8)
    ax5.bar(x_yr+0.2, h_yr.values/1e3,  0.35, label="Holiday Avg",
            color=C["yellow"], alpha=0.9)
    ax5.set_xticks(x_yr)
    ax5.set_xticklabels(h_yr.index.astype(str))
    ax5.set_ylabel("Avg Sales ($K)", **FL)
    ax5.set_title("Holiday vs Regular by Year", **FT)
    ax5.legend(fontsize=8)
    ax5.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}K"))

    plt.savefig(f"{OUTPUT_DIR}/04_holiday_seasonal.png", dpi=150,
                bbox_inches="tight", facecolor=C["bg"])
    plt.close()


def plot_advanced(df):
    fig = plt.figure(figsize=(20,14), facecolor=C["bg"])
    fig.suptitle("ADVANCED ANALYTICS & FORECASTING SIGNALS", fontsize=20,
                 fontweight="bold", color=C["dark"], y=0.98)
    fig.text(0.5, 0.955,
             "Rolling Averages · Volatility · Store Heatmap · Network Distribution",
             ha="center", fontsize=10, color=C["muted"])
    gs = gridspec.GridSpec(2, 3, figure=fig, hspace=0.45, wspace=0.38,
                           top=0.93, bottom=0.06, left=0.05, right=0.97)

    ax1  = fig.add_subplot(gs[0,:2])
    nw   = df.groupby("Date")["Weekly_Sales"].sum().reset_index().sort_values("Date")
    nw["Sales_M"] = nw["Weekly_Sales"]/1e6
    nw["MA4"]     = nw["Sales_M"].rolling(4).mean()
    nw["MA13"]    = nw["Sales_M"].rolling(13).mean()
    nw["Vol"]     = nw["Sales_M"].rolling(8).std()
    ax1.fill_between(nw["Date"], nw["Sales_M"], alpha=0.15, color=C["blue"])
    ax1.plot(nw["Date"], nw["Sales_M"], alpha=0.35, color=C["blue"], lw=1, label="Weekly (raw)")
    ax1.plot(nw["Date"], nw["MA4"],  color=C["orange"], lw=2.5, label="4-wk Moving Avg")
    ax1.plot(nw["Date"], nw["MA13"], color=C["green"],  lw=2.5, ls="--", label="13-wk (Quarterly) MA")
    ax1.set_ylabel("Network Sales ($M)", **FL)
    ax1.set_title("Network-Wide Sales with Rolling Averages", **FT)
    ax1.legend(fontsize=8)
    ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}M"))
    ax1.xaxis.set_major_formatter(plt.matplotlib.dates.DateFormatter("%b '%y"))
    ax1.tick_params(axis="x", rotation=30)
    ax1b = ax1.twinx()
    ax1b.fill_between(nw["Date"], nw["Vol"], alpha=0.2, color=C["red"])
    ax1b.set_ylabel("Volatility (Std $M)", color=C["red"], fontsize=8)
    ax1b.tick_params(axis="y", colors=C["red"], labelsize=7)

    ax2 = fig.add_subplot(gs[0,2])
    ax2.hist(df["Weekly_Sales"]/1e3, bins=60, color=C["blue"],
             alpha=0.75, edgecolor="white", linewidth=0.5)
    mean_v = df["Weekly_Sales"].mean()/1e3
    med_v  = df["Weekly_Sales"].median()/1e3
    ax2.axvline(mean_v, color=C["red"],    lw=2, ls="--", label=f"Mean  ${mean_v:.0f}K")
    ax2.axvline(med_v,  color=C["yellow"], lw=2, ls="--", label=f"Median ${med_v:.0f}K")
    ax2.set_xlabel("Weekly Sales ($K)", **FL)
    ax2.set_ylabel("Frequency", **FL)
    ax2.set_title("Sales Distribution", **FT)
    ax2.legend(fontsize=8)
    ax2.xaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}K"))

    ax3    = fig.add_subplot(gs[1,:2])
    top15  = df.groupby("Store")["Weekly_Sales"].sum().nlargest(15).index.tolist()
    df15   = df[df["Store"].isin(top15)].copy()
    df15["YM"] = df15["Date"].dt.to_period("M").astype(str)
    pivot  = df15.groupby(["Store","YM"])["Weekly_Sales"].mean().unstack().fillna(0)/1e3
    cols_s = pivot.columns[::3]
    pshow  = pivot[cols_s]
    im3    = ax3.imshow(pshow.values, cmap="YlOrRd", aspect="auto")
    plt.colorbar(im3, ax=ax3, label="Avg Weekly Sales ($K)", fraction=0.02, pad=0.01)
    ax3.set_yticks(range(len(pshow)))
    ax3.set_yticklabels([f"Store {s}" for s in pshow.index], fontsize=8)
    ax3.set_xticks(range(len(cols_s)))
    ax3.set_xticklabels(cols_s, rotation=45, ha="right", fontsize=7)
    ax3.set_title("Store × Monthly Sales Heatmap (Top 15 Stores)", **FT)

    ax4   = fig.add_subplot(gs[1,2])
    s_tot = df.groupby("Store")["Weekly_Sales"].sum()/1e6
    lbls  = ["Bottom 25%","25–50%","50–75%","75–90%","Top 10%"]
    cuts  = pd.qcut(s_tot, q=[0,.25,.50,.75,.90,1.0], labels=lbls)
    t_cnt = cuts.value_counts().reindex(lbls)
    t_rev = s_tot.groupby(cuts).sum().reindex(lbls)
    bps   = ax4.barh(lbls, t_rev.values,
                     color=[C["red"],"#FF8A65",C["yellow"],C["blue"],C["green"]],
                     edgecolor="white", linewidth=1.5, height=0.5)
    for bar, (cnt, rev) in zip(bps, zip(t_cnt, t_rev)):
        ax4.text(bar.get_width()+1, bar.get_y()+bar.get_height()/2,
                 f"${rev:.0f}M ({cnt} stores)", va="center", fontsize=8, color=C["dark"])
    ax4.set_xlabel("Total Revenue ($M)", **FL)
    ax4.set_title("Revenue by Store Tier", **FT)
    ax4.xaxis.set_major_formatter(plt.FuncFormatter(lambda x,_: f"${x:.0f}M"))
    ax4.set_xlim(0, t_rev.max()*1.55)

    plt.savefig(f"{OUTPUT_DIR}/05_advanced_analytics.png", dpi=150,
                bbox_inches="tight", facecolor=C["bg"])
    plt.close()


def main():
    df = load_data(DATA_PATH)
    plot_overview(df)
    plot_store_performance(df)
    plot_economic_factors(df)
    plot_holiday_seasonal(df)
    plot_advanced(df)


if __name__ == "__main__":
    main()
