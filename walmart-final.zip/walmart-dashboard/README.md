# 🛒 Walmart Business Insights Dashboard

![Python](https://img.shields.io/badge/Python-3.8%2B-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-150458?style=for-the-badge&logo=pandas&logoColor=white)
![Matplotlib](https://img.shields.io/badge/Matplotlib-11557C?style=for-the-badge)
![Jupyter](https://img.shields.io/badge/Jupyter-F37626?style=for-the-badge&logo=jupyter&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-22c55e?style=for-the-badge)

<br/>

> **Power BI–style analytics dashboard built entirely in Python.**
> Real Walmart sales data · 45 stores · $6.74 billion analyzed · 5 dashboard modules

---

## 📊 Dashboard

### Overview & Monthly Revenue Trend
![Overview Dashboard](images/01_overview_dashboard.png)

### Store Performance Analysis
![Store Performance](images/02_store_performance.png)

### Economic Factors Correlation
![Economic Factors](images/03_economic_factors.png)

### Holiday & Seasonal Patterns
![Holiday Seasonal](images/04_holiday_seasonal.png)

### Advanced Analytics & Forecasting Signals
![Advanced Analytics](images/05_advanced_analytics.png)

---

## 📁 Structure

```
walmart-dashboard/
├── walmart_dashboard.py       # All chart functions (importable module)
├── walmart_analysis.ipynb     # Jupyter notebook — full analysis walkthrough
├── data/
│   └── Walmart.csv            # Raw dataset — 6,435 weekly records
├── images/
│   ├── 01_overview_dashboard.png
│   ├── 02_store_performance.png
│   ├── 03_economic_factors.png
│   ├── 04_holiday_seasonal.png
│   └── 05_advanced_analytics.png
├── requirements.txt
└── README.md
```

---

## 🚀 Quick Start

```bash
git clone https://github.com/yourusername/walmart-dashboard.git
cd walmart-dashboard
pip install -r requirements.txt
python walmart_dashboard.py
```

Or open the notebook:

```bash
jupyter notebook walmart_analysis.ipynb
```

---

## 🗂️ Dataset

| Column | Type | Description |
|--------|------|-------------|
| `Store` | int | Store number (1 – 45) |
| `Date` | date | Week start date |
| `Weekly_Sales` | float | Store revenue for that week ($) |
| `Holiday_Flag` | int | 1 = Holiday week, 0 = Regular |
| `Temperature` | float | Regional temperature (°F) |
| `Fuel_Price` | float | Fuel cost in region ($/gallon) |
| `CPI` | float | Consumer Price Index |
| `Unemployment` | float | Regional unemployment rate (%) |

**Source:** [Walmart Store Sales — Kaggle](https://www.kaggle.com/datasets/yasserh/walmart-dataset)

---

## 📈 Dashboard Modules

| # | Module | Charts |
|---|--------|--------|
| 01 | **KPI Overview** | KPI cards · Monthly trend · Annual bars · Quarterly · YoY growth |
| 02 | **Store Performance** | All-45 ranking · Variability scatter · Box plots · Scorecard table |
| 03 | **Economic Factors** | Unemployment/Fuel/Temp scatter · Band bars · Correlation heatmap |
| 04 | **Holiday & Seasonal** | Holiday lift · Monthly seasonal pattern · Week-of-year · YoY split |
| 05 | **Advanced Analytics** | Rolling averages · Volatility · Store×month heatmap · Tier analysis |

---

## 💡 Key Findings

| Metric | Result |
|--------|--------|
| 🏆 Top Store | Store #20 — $301.4M over 3 years |
| 💰 Total Revenue | $6.74B across 45 stores |
| 📅 Peak Month | December (Holiday Season) |
| 🎉 Holiday Lift | +7.5% vs regular weeks |
| 📈 Best Year | 2011 — $2.45B total |
| 🔁 Seasonality | Strong Q4 spike, stable Q1–Q3 |
| 📉 Unemployment | Weak negative correlation (r ≈ −0.10) |

---

## 🔧 Requirements

```
pandas>=1.5.0
numpy>=1.23.0
matplotlib>=3.6.0
jupyter>=1.0.0
notebook>=6.5.0
```

---

## 🛠️ Tech Stack

| Tool | Use |
|------|-----|
| Python 3.8+ | Core language |
| Pandas | Data loading, feature engineering |
| NumPy | Statistical calculations |
| Matplotlib | All chart rendering & layout |
| Jupyter | Interactive notebook |

---

## 📄 License

MIT — free to use, fork, and adapt.

---

*Built with Python · matplotlib · pandas · Real Walmart Data*
